package chapter02;

public class ConsolePrintlnEscSeq {
	public static void main(String[] args) {
		System.out.println("\n줄바꿈\n연습\n");
		System.out.println("\t텝키\t연습\n");
		System.out.println("이것은\r 앞으로 이동합니다.\n");
		System.out.println("글자가 \"강조\"됩니다.\n");
		System.out.println("\\\\\\역슬래시 세개 출력");
	}
}
